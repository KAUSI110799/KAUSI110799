# Quiz-App
A quiz app created with GUI in python using tkinter.
